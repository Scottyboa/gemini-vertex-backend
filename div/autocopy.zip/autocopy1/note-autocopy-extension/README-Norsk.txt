Midlertidig installasjonsguide (mens Chrome Web Store-godkjenning pågår)

1. Last ned utvidelsens .zip-fil.
2. Pakk ut .zip-filen slik at du får en vanlig mappe.
3. I Chrome åpner du "chrome://extensions"(lim inn i URL og trykk enter)
4. Slå på Developer mode øverst til høyre.
5. Klikk Load unpacked.
6. Velg den utpakkede utvidelsesmappen.
7. Oppdater Transcribe Notes-siden.
8. Velg Auto-copy-modus i appen:
   - Transcript, eller
   - Note

Etter dette kan ferdige transkripsjoner eller ferdige notater kopieres automatisk til utklippstavlen, avhengig av hvilken modus som er valgt.

Viktig

- Off = ingen automatisk kopiering
- Transcript = automatisk kopiering når transkripsjonen er ferdig
- Note = automatisk kopiering når notatgenereringen er ferdig
- Manuelle Copy-knapper i appen kan fortsatt brukes når som helst

Varsler i Windows

For å få Chrome-varslet når kopieringen er fullført, må varsler være tillatt både i Windows og i Chrome. Hvis én av dem blokkerer varsler, kan popup-varslet utebli.

I Windows går du til:
Innstillinger -> System -> Varsler

I Chrome må varsler være tillatt for det aktuelle nettstedet under:
Innstillinger -> Personvern og sikkerhet -> Nettstedsinnstillinger -> Varsler

Kontroller også at Ikke forstyrr / Fokusassistent er slått av eller tillater Chrome.

Nytt i 1.3.0

- Autocopy-avkrysningsboksen i Redactor støttes nå. Når sladdingen er
  fullført, kopieres den sladdede transkripsjonen og det eksisterende
  systemvarslet vises.
- Redactor Autocopy fungerer uavhengig av hovedvalget Off / Transcript / Note.
  Når avkrysningsboksen i Redactor slås av, deaktiveres både kopieringen og
  varslet derfra.

Nytt i 1.4.0

- Auto-copy kjører nå inne i alle preset-arbeidsområder, ikke bare det første.
- Både tn-beta.netlify.app og scottyboa.github.io støttes.
- Hvis en eldre utpakket versjon allerede er installert, fjern den eller last
  inn den nye utpakkede 1.4.0-mappen på nytt fra chrome://extensions.

Nytt i 1.2.0

- Mini-panelet har nå en liten "hopp til fane"-knapp rett under
  lukke-knappen (X). Når du klikker på den, hentes Chrome-fanen som
  er valgt i mini-panelet frem - selv om Chrome er minimert eller
  ligger bak et annet program. Funksjonen krever at utvidelsen er
  installert; resten av mini-panelet fungerer uten.
- Ny "tabs"-tillatelse trengs for hopp-til-fane-funksjonen.
  Auto-kopi-oppførselen er uendret.
