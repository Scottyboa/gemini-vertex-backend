const OFFSCREEN_DOCUMENT_PATH = "offscreen.html";

async function showNotification(title, message) {
  try {
    const id = await chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title,
      message,
      priority: 2,
      requireInteraction: false
    });

    console.log("[AutoCopyExt] notification shown:", id, title, message);
  } catch (err) {
    console.error("[AutoCopyExt] Notification failed:", err);
  }
}

async function hasOffscreenDocument() {
  if (!chrome.runtime.getContexts) {
    return false;
  }

  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
  });

  return contexts.length > 0;
}

async function ensureOffscreenDocument() {
  const alreadyExists = await hasOffscreenDocument();

  if (alreadyExists) {
    return;
  }

  await chrome.offscreen.createDocument({
    url: OFFSCREEN_DOCUMENT_PATH,
    reasons: ["CLIPBOARD"],
    justification: "Copy finished notes to the clipboard when the app tab is not focused."
  });

  console.log("[AutoCopyExt] offscreen document created");
}

async function sendOffscreenCopy(text) {
  await ensureOffscreenDocument();

  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      {
        type: "OFFSCREEN_COPY",
        text
      },
      (response) => {
        const err = chrome.runtime?.lastError;
        if (err) {
          resolve({ ok: false, error: err.message });
          return;
        }

        resolve(response || { ok: false, error: "No response from offscreen document." });
      }
    );
  });
}

function getCopyLabels(copyKind) {
  const kind = String(copyKind || "").trim().toLowerCase();

  if (kind === "transcript") {
    return {
      successTitle: "Transcript completed",
      successMessage: "Transcript copied to clipboard.",
      failureTitle: "Transcript completed",
      failureMessage: "Could not copy transcript to clipboard."
    };
  }

  return {
    successTitle: "Note generation completed",
    successMessage: "Note copied to clipboard.",
    failureTitle: "Note generation completed",
    failureMessage: "Could not copy note to clipboard."
  };
}

// =====================================================================
// Focus-this-tab handler
// =====================================================================
//
// When the content script forwards a FOCUS_THIS_TAB request, we know
// the sending tab is the one the user wants in the foreground. We use
// the standard chrome.tabs/chrome.windows APIs:
//
//   - chrome.tabs.update({active: true})  -> select the tab inside its window
//   - chrome.windows.update({focused: true, state: 'normal'})
//        -> bring the window to the foreground; un-minimize if needed
//
// Unlike a plain window.focus() from a web page, this works even if
// Chrome is minimized, behind another app, or on a different desktop.
async function focusSenderTab(sender) {
  const tab = sender?.tab;
  if (!tab || typeof tab.id !== "number") {
    return { ok: false, error: "Sender tab id unavailable." };
  }

  try {
    // Activate the tab inside its window first.
    await chrome.tabs.update(tab.id, { active: true });
  } catch (err) {
    console.warn("[AutoCopyExt] chrome.tabs.update failed:", err);
    return { ok: false, error: err?.message || String(err) };
  }

  // Then raise / un-minimize the window. Some platforms reject
  // 'state: normal' if the window is already in another non-minimized
  // state, so we only set it when the window is currently minimized.
  if (typeof tab.windowId === "number") {
    try {
      let updateProps = { focused: true };

      try {
        const win = await chrome.windows.get(tab.windowId);
        if (win && win.state === "minimized") {
          updateProps.state = "normal";
        }
      } catch (_) {
        // If we can't read the state, just request focus.
      }

      await chrome.windows.update(tab.windowId, updateProps);
    } catch (err) {
      console.warn("[AutoCopyExt] chrome.windows.update failed:", err);
      // Tab activation already succeeded, so report partial success.
      return { ok: true, partial: true, error: err?.message || String(err) };
    }
  }

  return { ok: true };
}

chrome.runtime.onInstalled.addListener(() => {
  console.log("[AutoCopyExt] service worker installed");
});

chrome.runtime.onStartup?.addListener(() => {
  console.log("[AutoCopyExt] service worker started");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;

  console.log("[AutoCopyExt] onMessage received:", message?.type);

  if (message.type === "COPY_TEXT") {
    (async () => {
      try {
        const text = typeof message.text === "string" ? message.text : "";
        const labels = getCopyLabels(message.copyKind);

        if (!text.trim()) {
          await showNotification(
            labels.failureTitle,
            labels.failureMessage
          );
          sendResponse({ ok: false, error: "No text provided." });
          return;
        }

        const result = await sendOffscreenCopy(text);

        if (result?.ok) {
          await showNotification(
            labels.successTitle,
            labels.successMessage
          );
          sendResponse({ ok: true });
          return;
        }

        await showNotification(
          labels.failureTitle,
          labels.failureMessage
        );

        sendResponse({
          ok: false,
          error: result?.error || "Clipboard copy failed."
        });
      } catch (err) {
        console.error("[AutoCopyExt] COPY_TEXT failed:", err);
        const labels = getCopyLabels(message.copyKind);

        try {
          await showNotification(
            labels.failureTitle,
            labels.failureMessage
          );
        } catch (_) {}

        sendResponse({
          ok: false,
          error: err?.message || String(err)
        });
      }
    })();

    return true;
  }

  if (message.type === "FOCUS_THIS_TAB") {
    (async () => {
      try {
        const result = await focusSenderTab(sender);
        sendResponse(result);
      } catch (err) {
        console.error("[AutoCopyExt] FOCUS_THIS_TAB failed:", err);
        sendResponse({ ok: false, error: err?.message || String(err) });
      }
    })();

    return true;
  }
});
